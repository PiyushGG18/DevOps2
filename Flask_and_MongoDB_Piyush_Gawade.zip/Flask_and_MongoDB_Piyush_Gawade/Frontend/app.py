from flask import Flask, render_template, request, redirect, url_for
import requests

BACKEND_URL = 'http://0.0.0.0:9000'

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/submit', methods=['POST'])
def submit():
    form_data = dict(request.form)

    try:
        response = requests.post(
            BACKEND_URL + '/submit',
            json=form_data,
            timeout=5
        )

        response.raise_for_status()

        return redirect(url_for('success'))

    except requests.exceptions.RequestException as e:
        try:
            error_message = response.json().get('error', str(e))
        except (ValueError, UnboundLocalError):
            error_message = str(e)

        return render_template('index.html', error=error_message)

@app.route('/success')
def success():
    return render_template('success.html')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8000, debug=True)