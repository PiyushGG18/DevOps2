from flask import Flask, jsonify
import json

app = Flask(__name__)

@app.route('/api')
def data():
    file = open('data.json', 'r')
    content = json.load(file)

    return jsonify(content)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8000, debug=True)