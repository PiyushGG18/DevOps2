from flask import Flask, request, jsonify
from dotenv import load_dotenv
import os
import pymongo

load_dotenv()

MONGO_URI = os.getenv('MONGO_URI')

client = pymongo.MongoClient(MONGO_URI)
db = client.test
collection = db['assignment']

app = Flask(__name__)

@app.route('/submit', methods=['POST'])
def submit():
    try:
        form_data = request.json

        if not form_data or not form_data.get('name') or not form_data.get('email'):
            return jsonify({'error': 'Name and email are required'}), 400

        collection.insert_one(form_data)

        return jsonify({'message': 'Data submitted successfully!'}), 201

    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=9000, debug=True)