# Python and Bash Lab

## Objective
1. Grade Checker
2. Student Grades
3. Write to a File
4. Read from a File

## Tasks Performed
1. Created 'grade_checker.py' which uses if-else statement to determine student's grade based on their score.
![grade_checker.png](/screenshots/grade_checker.png)

2. Created 'student_grades.py' program which uses python's dictionary object to keep track of students and their respective grades.
![student_grades.png](/screenshots/student_grades.png)

3. Created 'write_file.py' program which writes down a new line in 'test.txt' file.
![write_file.png](/screenshots/write_file.png)

4. Created 'read_file.py' program which reads from 'test.txt' file.
![read_file.png](/screenshots/read_file.png)

## Lab Status 
Completed successfully