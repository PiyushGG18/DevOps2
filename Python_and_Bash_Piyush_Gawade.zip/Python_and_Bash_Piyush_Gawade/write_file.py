file = open('./test.txt', 'a')

file.write('New line has been added\n')

file.close()