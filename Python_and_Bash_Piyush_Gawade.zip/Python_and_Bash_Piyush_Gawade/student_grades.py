dictionary = {
    "John": "B",
    "Jacob": "A",
    "Justin": "D"
}

while True:
    print("What action would you like to perform?")
    print("1. Add a new student and grade \n" 
        "2. Update an existing student's grade. \n"
        "3. Print all student grades \n"
        "4. Quit")

    option = int(input())


    if option == 1:
        print("Please enter student name:")
        name = input()
        print("Please enter " + name + "'s grade:")
        grade = input()
        dictionary[name] = grade

    elif option == 2:
        print("Enter student name whose grade must be updated:")
        name = input()
        print("Please enter new grade:")
        grade = input()
        dictionary[name] = grade

    elif option == 3:
        print(dictionary)

    elif option == 4:
        print("Exiting the program")
        break

    else: 
        print("Not a valid operation")